/****************************************************************************
 *                                                                          *
 * File    : main.c                                                         *
 *                                                                          *
 * Purpose : Generic Pocket PC application.                                 *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

#define UNICODE
#include <windows.h>
#include <windowsx.h>
#include <aygshell.h>
#include "main.h"

#define NELEMS(a)  (sizeof(a) / sizeof((a)[0]))

/** Prototypes **************************************************************/

static LRESULT WINAPI MainWndProc(HWND, UINT, WPARAM, LPARAM);
static BOOL Main_OnCreate(HWND, CREATESTRUCT *);
static void Main_OnActivate(HWND, UINT, HWND, BOOL);
static void Main_OnSettingChange(HWND, UINT, PCTSTR);
static void Main_OnPaint(HWND);
static void Main_OnCommand(HWND, int, HWND, UINT);
static void Main_OnDestroy(HWND);
static LRESULT WINAPI AboutDlgProc(HWND, UINT, WPARAM, LPARAM);

/** Global variables ********************************************************/

static HANDLE ghInstance;
static HWND ghwndMB;
static SHACTIVATEINFO gsai = { sizeof(SHACTIVATEINFO) };

HWND ghwnd, hEditDump, hEditR0, hButtonRun;

#define SIZER0 100
#define SIZECODE 512
#define SIZEDUMP (SIZECODE*20+8)

wchar_t bufdump[SIZEDUMP];
wchar_t bufR0[SIZER0];
unsigned int bufcode[SIZECODE];
wchar_t buftrace[1000];

/*** f ***/

int f (int a, int b)
{
	int c;
	c = a + 0xAB;
	c = c & 0xCD;
	// MessageBox (ghwnd, L"Hello !", L"Test", MB_OK);
	return c;
}

void create_text (wchar_t *buf)
{
	int i;
	union
	{
		int (*f)();
		unsigned int *p;
	} u;
	u.f = f;
	for (i=0; i<10; i++)
		swprintf (buf+i*20, L"%08X: %08X\r\n", &(u.p[i]), u.p[i]);
	buf[i*20] = 0;
}

void dump (unsigned int *code, int n, wchar_t *buf)
{
	int i;
	for (i=0; i<n; i++)
		swprintf (buf+i*20, L"%08X: %08X\r\n", &(code[i]), code[i]);
	buf[n*20] = 0;
}

void loadcode (wchar_t *buf)
{
	int i, j, k, e;
	e = 1; i=0; j=0;
	wchar_t bufadr[30], bufval[30];
	int adr, adr1, adr0;
	unsigned int val;
	union
	{
		int adr;
		unsigned int *ptr;
	} u;
	adr0 = 0;
	swprintf (buftrace, L"%X", &adr0);
	// MessageBox (ghwnd, buftrace, L"trace", MB_OK);
	int adrel;
	adrel = 0;
	for (k=0; buf[k]!=0; k++)
	{
		switch (e)
		{
			case 1:
				if (buf[k] == ':')
				{
					bufadr[i] = 0;
					e = 2;
					j = 0;
				}
				else if (buf[k] == '\r' || buf[k] == '\n')
					i = 0;
				else
					bufadr[i++] = buf[k];
				break;
			case 2:
				if (buf[k] == '\r' ||buf[k] == '\n')
				{
					bufval[j] = 0;
					adr1 = 0;
					swscanf (bufadr, L"%X", &adr1);
					swprintf (buftrace, L"adr1=%X bufadr=<%s>", adr1, bufadr);
					// MessageBox (ghwnd, buftrace, L"trace", MB_OK);
					if (adr0 == 0)
					{
						adr0 = adr1;
						swprintf (buftrace, L"adr0=%X", adr0);
						// MessageBox (ghwnd, buftrace, L"trace", MB_OK);
						adr = adr1;
					}
					else if (adr1 == 0)
						adr = adr + 4;
					else
						adr = adr1;
					swscanf (bufval, L"%X", &val);
					u.adr = adr;
					// *(u.ptr) = val;
					// bufcode[adrel++] = val;
					swprintf (buftrace, L"adr1=%X adr=%X val=%X", adr1, adr, val);
					// MessageBox(ghwnd,buftrace,L"trace",MB_OK);
					bufcode[(adr-adr0)/4] = val;
					e = 1;
					i = 0;
				}
				else
					bufval[j++] = buf[k];
				break;
			default:
				e = 1;
				i = 0;
				break;

		}
	}
}

/****************************************************************************
 *                                                                          *
 * Function: WinMain                                                        *
 *                                                                          *
 * Purpose : Initialize the application.  Register a window class,          *
 *           create and display the main window and enter the               *
 *           message loop.                                                  *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPWSTR lpszCmdLine, int nCmdShow)
{
    HWND hwnd;
    MSG msg;

    /* Always check first if program is already running */
    hwnd = FindWindow(L"exparmClass", NULL);
    if (hwnd)
    {
        /*
         * Set focus to the foremost child window. The "|0x01" is used to
         * bring any owned windows to the foreground and activate them.
         */
        SetForegroundWindow((HWND)((ULONG)hwnd|0x00000001));
        return 0;
    }

    if (!hPrevInstance)
    {
        WNDCLASS wc;

        wc.lpszClassName = L"exparmClass";
        wc.lpfnWndProc = MainWndProc;
        wc.style = CS_VREDRAW|CS_HREDRAW;
        wc.hInstance = hInstance;
        wc.hIcon = NULL;
        wc.hCursor = NULL;
        wc.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
        wc.lpszMenuName = NULL;
        wc.cbClsExtra = 0;
        wc.cbWndExtra = 0;

        if (!RegisterClass(&wc))
            return 1;
    }

    ghInstance = hInstance;

    hwnd = CreateWindowEx(
        0,
        L"exparmClass",
        L"exparm Program",
        WS_VISIBLE|WS_SYSMENU,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        NULL,
        NULL,
        hInstance,
        NULL
    );
    if (!hwnd) return 1;

    /*
     * When CW_USEDEFAULT is used to create the main window, the height of the
     * menu bar is not considered. We must manually reserve space for the menu.
     */
    if (ghwndMB)
    {
        RECT rcWin, rcMB;

        GetWindowRect(hwnd, &rcWin);
        GetWindowRect(ghwndMB, &rcMB);
        rcWin.bottom -= (rcMB.bottom - rcMB.top);
        MoveWindow(hwnd, rcWin.left, rcWin.top, rcWin.right - rcWin.left, rcWin.bottom - rcWin.top, FALSE);
    }

    // create_text (bufdump);

      union
	{
		int (*f)();
		unsigned int *p;
	} u;
	u.f = f;

	dump (u.p, 16, bufdump);

	int i;
	for (i=0; i<16; i++)
		bufcode[i] = u.p[i];
    
    hEditDump = CreateWindow (L"EDIT", bufdump,
		WS_VISIBLE | WS_CHILD | WS_BORDER | WS_VSCROLL | WS_HSCROLL | 
		ES_MULTILINE | ES_WANTRETURN | ES_AUTOVSCROLL | ES_AUTOHSCROLL,
		10, 40, 220, 130,
		hwnd, NULL, ghInstance, NULL);

    hEditR0 = CreateWindow (L"EDIT", L"",
		WS_CHILD | WS_VISIBLE | ES_LEFT | WS_BORDER,
		100, 10, 130, 20,
		hwnd, NULL, ghInstance, NULL);

    hButtonRun = CreateWindow (L"BUTTON", L"Run", 
		WS_CHILD | WS_VISIBLE | ES_LEFT | WS_BORDER,
		10, 10, 80, 20,
		hwnd, NULL, ghInstance, NULL);

    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    while (GetMessage(&msg, NULL, 0, 0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return msg.wParam;
}

/****************************************************************************
 *                                                                          *
 * Function: MainWndProc                                                    *
 *                                                                          *
 * Purpose : Process application messages.                                  *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static LRESULT CALLBACK MainWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
        HANDLE_MSG(hwnd, WM_CREATE, Main_OnCreate);
        HANDLE_MSG(hwnd, WM_ACTIVATE, Main_OnActivate);
        HANDLE_MSG(hwnd, WM_SETTINGCHANGE, Main_OnSettingChange);
        HANDLE_MSG(hwnd, WM_PAINT, Main_OnPaint);
        HANDLE_MSG(hwnd, WM_COMMAND, Main_OnCommand);
        HANDLE_MSG(hwnd, WM_DESTROY, Main_OnDestroy);
        /* TODO: enter more messages here */
        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }
}

/****************************************************************************
 *                                                                          *
 * Function: Main_OnCreate                                                  *
 *                                                                          *
 * Purpose : Process a WM_CREATE message.                                   *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static BOOL Main_OnCreate(HWND hwnd, CREATESTRUCT *pcs)
{
    SHMENUBARINFO mbi;

    memset(&mbi, 0, sizeof(mbi));
    mbi.cbSize = sizeof(mbi);
    mbi.hwndParent = hwnd;
    mbi.nToolBarId = IDR_MNU_MAIN;
    mbi.hInstRes = ghInstance;
    mbi.nBmpId = 0;
    mbi.cBmpImages = 0;
    if (!SHCreateMenuBar(&mbi))  /* create the menu bar */
        return FALSE;

    ghwndMB = mbi.hwndMB;

    return TRUE;
}

/****************************************************************************
 *                                                                          *
 * Function: Main_OnActivate                                                *
 *                                                                          *
 * Purpose : Process a WM_ACTIVATE message.                                 *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static void Main_OnActivate(HWND hwnd, UINT state, HWND hwndActDeact, BOOL fMinimized)
{
    /* Notify the shell of our activate message */
    SHHandleWMActivate(hwnd, MAKEWPARAM(state,fMinimized), (LPARAM)hwndActDeact, &gsai, 0);
}

/****************************************************************************
 *                                                                          *
 * Function: Main_OnSettingChange                                           *
 *                                                                          *
 * Purpose : Process a WM_SETTINGCHANGE message.                            *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static void Main_OnSettingChange(HWND hwnd, UINT uiAction, PCTSTR pszSection)
{
    switch (uiAction)
    {
        case SPI_SETSIPINFO:
        {
            /* Adjust window size depending on SIP panel */
            SHHandleWMSettingChange(hwnd, -1, 0, &gsai);
            break;
        }
    }
}

/****************************************************************************
 *                                                                          *
 * Function: Main_OnPaint                                                   *
 *                                                                          *
 * Purpose : Process a WM_PAINT message.                                    *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static void Main_OnPaint(HWND hwnd)
{
    PAINTSTRUCT ps;
    RECT rc;

    BeginPaint(hwnd, &ps);
    GetClientRect(hwnd, &rc);
    DrawText(ps.hdc, L"Hello, Windows CE!", -1, &rc, DT_CENTER|DT_VCENTER);
    EndPaint(hwnd, &ps);
}

/*** traiter ***/

int traiter1 (wchar_t *buf, int r0)
{
	buf[1] = r0;
	r0 = buf[2];
	return r0;
}


int traiter (wchar_t *buf, int r0)
{
	int r0n;
	int n;
       union
	{
		int (*f)();
		unsigned int *p;
	} u;
	// MessageBox (ghwnd, L"Traitement", L"trace", MB_OK);
	loadcode (buf);
	// MessageBox (ghwnd, L"code charg�", L"trace", MB_OK);
	u.p = bufcode;
	// MessageBox (ghwnd, L"...", L"trace", MB_OK);
	r0n = (*(u.f)) (r0);
	// r0n = 0xABCD;
	// MessageBox (ghwnd, L"dump", L"trace", MB_OK);
	dump (bufcode, SIZECODE,  bufdump);
	// MessageBox (ghwnd, bufdump, L"bufdump", MB_OK);
	return r0n;
}


/*** run ***/

void run (HWND hwnd)
{
	int r0;
	ghwnd = hwnd;
	SendMessage (hEditDump, WM_GETTEXT, SIZEDUMP, (long)bufdump);
	SendMessage (hEditR0, WM_GETTEXT, SIZER0, (long)bufR0);
	swscanf (bufR0, L"%X", &r0);
	r0 = traiter (bufdump, r0);
	swprintf (bufR0, L"%X", r0);
	SendMessage (hEditDump, WM_SETTEXT, SIZEDUMP, (long)bufdump);
	SendMessage (hEditR0, WM_SETTEXT, SIZER0, (long)bufR0);
}


/****************************************************************************
 *                                                                          *
 * Function: Main_OnCommand                                                 *
 *                                                                          *
 * Purpose : Process a WM_COMMAND message.                                  *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static void Main_OnCommand(HWND hwnd, int id, HWND hwndCtl, UINT codeNotify)
{
    if (hwndCtl == hButtonRun)
	{
		run(hwnd);
	}
    switch (id)
    {
        case IDM_ABOUT:
            DialogBox(ghInstance, MAKEINTRESOURCE(DLG_ABOUT), hwnd, (DLGPROC)AboutDlgProc);
            break;

        case IDOK:
            SendMessage(hwnd, WM_CLOSE, 0, 0);
            break;

        default:
            FORWARD_WM_COMMAND(hwnd, id, hwndCtl, codeNotify, DefWindowProc);
            break;

        /* TODO: Enter more commands here */
    }
}

/****************************************************************************
 *                                                                          *
 * Function: Main_OnDestroy                                                 *
 *                                                                          *
 * Purpose : Process a WM_DESTROY message.                                  *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static void Main_OnDestroy(HWND hwnd)
{
    DestroyWindow(ghwndMB);
    PostQuitMessage(0);
}

/****************************************************************************
 *                                                                          *
 * Function: AboutDlgProc                                                   *
 *                                                                          *
 * Purpose : Process messages for the About dialog.  The dialog is          *
             shown when the user selects "About" in the "Help" menu.        *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static LRESULT CALLBACK AboutDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)
    {
        case WM_INITDIALOG:
        {
            SHINITDLGINFO shidi;

            /*
             * Create a Done button and size the dialog.
             */
            shidi.dwMask = SHIDIM_FLAGS;
            shidi.dwFlags = SHIDIF_DONEBUTTON|SHIDIF_SIPDOWN|SHIDIF_SIZEDLGFULLSCREEN;
            shidi.hDlg = hDlg;
            SHInitDialog(&shidi);
            return TRUE;
        }

        case WM_COMMAND:
            switch (wParam)
            {
                case IDOK:
                    /*
                     * OK was clicked, close the dialog.
                     */
                    EndDialog(hDlg, TRUE);
			exit(0);
                    return TRUE;
            }
            break;
    }

    return FALSE;
}
