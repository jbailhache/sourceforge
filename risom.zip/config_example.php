
<?php

 $prefix = 'risom_';

 function get_local_url ()
 {
  return 'http://www.nomdemonsite.fr/risom/';
 }

 function get_host ()
 {
  return 'localhost';
 }

 function get_user ()
 {
  return 'root';
 }
 
 function get_pass ()
 {
  return 'password';
 }

 function get_db ()
 {
  return 'mysqldbname';
 }


?>
