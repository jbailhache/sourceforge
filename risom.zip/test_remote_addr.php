<html>
<body>
Remote address: 
<?php echo $_SERVER['REMOTE_ADDR']; ?>
</body>
</html>

