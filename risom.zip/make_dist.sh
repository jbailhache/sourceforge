mv *.zip ..
zip risom.zip *

