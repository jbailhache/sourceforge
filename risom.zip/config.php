<?php

 $prefix = 'risom3_';

 function get_local_url ()
 {
  return 'http://jacquesb.no-ip.org/risom3/';
 }

 function get_host ()
 {
  return 'localhost';
 }

 function get_user ()
 {
  return 'root';
 }
 
 function get_pass ()
 {
  return 'zareko';
 }

 function get_db ()
 {
  return 'risom';
 }


?>
