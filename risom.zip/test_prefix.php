<?php
 include "platform.php";
 echo $prefix . "xxx";
?>
