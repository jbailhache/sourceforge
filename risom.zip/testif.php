<?php
 if (0) 
 { 
  echo " zero ";
 }
 else
 {
  echo " non ";
 }
?>

