
main ()
{
int t;
int x, y;
 init_graph();

/*
 for (t=1; t<100; t++)
  plot(t,t);
*/

 plot (210, 40);
 draw_string (210, 40, "Bonjour !");
 
 for (t=0; t<1000; t++)
 {
  x = 100+90*sin((float)(t*t)/5);
  y = 100+90*cos((float)t/6);
  /* printf ("%d %d\n", x, y); */
  plot (x, y);
 }

 for (;;) sleep(1);
}

