
main ()
{
char buf[100];
char buf1[1000];
char *p;
 *buf1 = 0;
 strcpy (buf, "ANGLE(M,A,B)=63.8763");
 p = buf;
 strtok (p, "(");
 printf ("<%s>\n", buf1);
}
