execfile('local.py')
execfile('util.py')
execfile('matrix.py')
execfile('graph.py')
execfile('bourse.py')
execfile('anatech.py')
execfile('indic.py')
# execfile('testindic.py')
execfile('heuris.py')
# execfile('testbourse.py')
execfile('evol.py')
execfile('combtvgc.py')
l0=1000
execfile('decal.py')
execfile('normcours.py')
# execfile('select.py')
execfile('srd.py')
execfile('lc.py')
execfile('lh.py')
execfile('warrants.py')
execfile('select.py')
execfile('indicsn.py')
execfile('rlmn.py')
execfile('optim.py')
execfile('testpo.py')
execfile('afchid.py')
execfile('warrants_sg.py')
p=params([],[])
t1=40
wd=800



