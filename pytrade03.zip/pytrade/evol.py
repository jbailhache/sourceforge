 
heur = [[[1.3099819999999995, [0.5, -1.0, -0.5, 0.0, 1.0, -1.0, -1.0, -1.0, 0.0]], [1.3099819999999995, [0.5, 1.0, -0.5, 0.0, -1.0, -1.0, 1.0, -1.0, 0.0]], [1.2974730000000003, [0.5, -1.0, -0.5, 0.0, -1.0, 1.0, 1.0, 1.0, -1.0]], [1.2974730000000003, [0.5, 1.0, -0.5, 0.0, 1.0, 1.0, -1.0, 1.0, 1.0]], [1.2936300000000007, [0.0, 0.5, 0.0, -1.0, -1.0, -1.0, 1.0, 0.0, -1.0]], [1.2936300000000007, [0.0, 1.0, 0.0, -1.0, -1.0, -1.0, 1.0, 0.0, -1.0]], [1.2936300000000007, [0.0, -1.0, 0.0, -1.0, 1.0, -1.0, -1.0, 0.0, 1.0]], [1.2936300000000007, [0.0, -0.5, 0.0, -1.0, 1.0, -1.0, -1.0, 0.0, 1.0]], [1.2921180000000003, [-0.5, -1.0, 0.0, 0.0, 0.5, 0.0, -1.0, 0.5, 0.0]], [1.2921180000000003, [-0.5, 1.0, 0.0, 0.0, -0.5, 0.0, 1.0, 0.5, 0.0]], [1.2695420000000008, [1.0, -0.5, -1.0, 0.0, -1.0, 1.0, 1.0, 1.0, -1.0]], [1.2695420000000008, [1.0, 0.5, -1.0, 0.0, 1.0, 1.0, -1.0, 1.0, 1.0]], [1.2627049999999997, [-0.5, -1.0, 0.0, -0.5, 1.0, 0.0, -1.0, 1.0, 0.0]], [1.2627049999999997, [-0.5, 1.0, 0.0, -0.5, -1.0, 0.0, 1.0, 1.0, 0.0]], [1.2617530000000001, [0.5, -1.0, -1.0, 1.0, 1.0, -1.0, -1.0, 1.0, -1.0]], [1.2617530000000001, [1.0, -1.0, -1.0, 1.0, 1.0, -1.0, -1.0, 1.0, -1.0]]], [[1.6118820000000009, [-1.0, 1.0, -1.0, 0.0, 1.0, 1.0, -1.0, -0.5, -1.0]], [1.6118820000000009, [-0.5, 0.5, -0.5, 0.0, 1.0, 1.0, -1.0, -0.5, -1.0]], [1.6118820000000009, [-0.5, 1.0, -0.5, -0.5, 1.0, 0.5, -1.0, 0.0, -1.0]], [1.6118820000000009, [0.0, 1.0, -1.0, 0.0, 1.0, 0.0, -1.0, -0.5, -0.5]], [1.6118820000000009, [0.0, 0.5, -0.5, 0.0, 1.0, 0.0, -1.0, -0.5, -0.5]], [1.6118820000000009, [-1.0, 1.0, -0.5, 0.0, 1.0, 1.0, -1.0, -0.5, -0.5]], [1.6118820000000009, [0.5, -0.5, -1.0, -0.5, -1.0, -0.5, 1.0, 0.0, -0.5]], [1.6118820000000009, [0.0, -1.0, -1.0, 0.0, -1.0, 0.0, 1.0, -0.5, 0.5]], [1.6118820000000009, [0.0, -0.5, -0.5, 0.0, -1.0, 0.0, 1.0, -0.5, 0.5]], [1.6118820000000009, [-1.0, -1.0, -0.5, 0.0, -1.0, 1.0, 1.0, -0.5, 0.5]], [1.6118820000000009, [0.5, 0.5, -1.0, -0.5, 1.0, -0.5, -1.0, 0.0, 0.5]], [1.6118820000000009, [-1.0, -1.0, -1.0, 0.0, -1.0, 1.0, 1.0, -0.5, 1.0]], [1.6118820000000009, [-0.5, -0.5, -0.5, 0.0, -1.0, 1.0, 1.0, -0.5, 1.0]], [1.6118820000000009, [-0.5, -1.0, -0.5, -0.5, -1.0, 0.5, 1.0, 0.0, 1.0]], [1.6115390000000012, [-0.5, 1.0, 0.0, 0.0, 1.0, 1.0, -1.0, -0.5, -0.5]], [1.6115390000000012, [0.5, 1.0, -1.0, -0.5, 1.0, -1.0, -1.0, 0.0, -0.5]]], [[1.549045, [-1.0, 0.0, -0.5, 0.0, 1.0, -1.0, -1.0, 0.0, -0.5]], [1.549045, [-1.0, 0.0, -0.5, 0.0, -1.0, -1.0, 1.0, 0.0, 0.5]], [1.5030310000000002, [-1.0, -0.5, -0.5, 0.0, 1.0, 0.0, -1.0, 0.0, 0.0]], [1.5030310000000002, [-1.0, 0.5, -0.5, 0.0, -1.0, 0.0, 1.0, 0.0, 0.0]], [1.5001289999999998, [-1.0, -0.5, -1.0, 0.0, 1.0, -0.5, -1.0, 0.0, 0.0]], [1.5001289999999998, [-1.0, 0.5, -1.0, 0.0, -1.0, -0.5, 1.0, 0.0, 0.0]], [1.4901400000000005, [-1.0, -1.0, 0.5, 0.0, 1.0, -1.0, -1.0, 0.0, -1.0]], [1.4901400000000005, [-1.0, 1.0, 0.5, 0.0, -1.0, -1.0, 1.0, 0.0, 1.0]], [1.4841, [-1.0, -0.5, -1.0, 0.0, -1.0, -1.0, 1.0, 0.0, -1.0]], [1.4841, [-1.0, -0.5, -1.0, 0.0, 1.0, 0.0, -1.0, 0.0, -0.5]], [1.4841, [-1.0, 0.0, -1.0, 0.0, -1.0, -1.0, 1.0, 0.0, -0.5]], [1.4841, [-0.5, 0.0, -0.5, 0.0, -1.0, -1.0, 1.0, 0.0, -0.5]], [1.4841, [-1.0, 0.0, -1.0, 0.0, 1.0, -1.0, -1.0, 0.0, 0.5]], [1.4841, [-0.5, 0.0, -0.5, 0.0, 1.0, -1.0, -1.0, 0.0, 0.5]], [1.4841, [-1.0, 0.5, -1.0, 0.0, -1.0, 0.0, 1.0, 0.0, 0.5]], [1.4841, [-1.0, 0.5, -1.0, 0.0, 1.0, -1.0, -1.0, 0.0, 1.0]]]]

def expansex(x):
 y = [0.0 for i in range(28)]
 y[1] = 1.0
 y[5] = x[0]
 y[6] = x[1]
 y[8] = x[2]
 y[11] = x[3]
 y[12] = x[4]
 y[14] = x[5]
 y[17] = x[6]
 y[18] = x[7]
 y[20] = x[8]
 return y

nq = 4
if ohbc:
  nd=nq*(nq+6)
else:
  nd = nq * (nq + 3)

def qimtc(x):
  if len(x) != nd:
    print '*** erreur : len(x)=', len(x), ' x=', x
  qi = [x[i] for i in range(nq)]
  print 'len(x)=',len(x),' nq=',nq
  mt = [[x[nq+(nq+2)*i+j] for j in range(nq+2)] for i in range(nq)]
  # suppression des termes constants
  # for i in range(nq):
  #   mt[i][nq+1] = 0
  return [qi,mt]

def qimtohbc(x):
  if len(x) != nd:
    print '*** erreur : len(x)=', len(x), ' x=', x
  qi = [x[i] for i in range(nq)]
  print 'len(x)=',len(x),' nq=',nq
  # mt = [[x[nq+(nq+5)*i+j] for j in range(nq+5)] for i in range(nq)]
  print len(x)
  mt = [[x[nq+(nq+ny)*i+j] for j in range(nq+ny)] for i in range(nq)]
  # suppression des termes constants
  # for i in range(nq):
  #   mt[i][nq+1] = 0
  return [qi,mt]

def qimt(x):
  if ohbc:
    return qimtohbc(x)
  else:
    return qimtc(x)

def valeur(x):
  p = qimt(x)
  r = moyind (select, calculind4, p)
  return r[0]

def valeurc(x,c):
  p = qimt(x)
  # r = moyindc (c, calculind4, p)
  # r = minindc (c, calculind4, p)
  # return r[0]
  r1 = moyindc (c, calculind4, p)
  r2 = minindc (c, calculind4, p)
  res = (r1[0] + r2[0]) / 2
  # res = r1[0]
  f = open('valeurc.txt','a')
  f.write(str(res) + ' ' + str(x) + '\n')
  f.close()
  return res

def extractxs(h):
 l = []
 for a in h:
  for b in a:
   l = l + [b[1]]
 return l

def extractexpxs(h):
 l = extractxs(h)
 return [expansex(x) for x in l]

def valeursxs(l):
 return [[valeur(x),x] for x in l]

maxi = 96

def popinit(h,n):
 l = extractexpxs(h)
 p = valeursxs(l)
 r = p
 while len(r)<n:
  r = r + p
 r = r[0:n]
 return r

def valeursxsc(l,c):
 return [[valeurc(x,c),x] for x in l]

def popinitc(h,n,c):
 l = extractexpxs(h)
 p = valeursxsc(l,c)
 r = p
 while len(r)<n:
  r = r + p
 r = r[0:n]
 x = vecteurqimt(qi3macd,mt3macd(12,26,9))
 v = valeurc(x,c)
 r = r + [[v,x]]
 return r


def randx():
  return [uniform(-1.0,1.0) for i in range(nd)]

def randpopinit(n,c):
  p = []
  for i in range(n):
    x = randx()
    v = valeurc(x,c)
    p = p + [[v,x]]
  return p

select = []
# select = select + ['HERMES']
select = select + ['ALTEN']
select = select + ['ILIAD']
select = select + ['BOUYGUES']
select = select + ['LVMH MOET HENNESSY']
select = select + ['PPR']
# select = select + ['VINCI']
select = select + ['VIVENDI']
# select = select + ['DEXIA']
select = select + ['BNP PARIBAS']
select = select + ['RENAULT']
# select = select + ['FRANCE TELECOM']
select = select + ['GDF SUEZ']
 

select2 = []
select2 = select2 + ['BIOMERIEUX']
select2 = select2 + ['AIR FRANCE - KLM']
select2 = select2 + ['CREDIT AGRICOLE']
select2 = select2 + ['EADS']
# select = select + ['AIR LIQUIDE']
select2 = select2 + ['CARREFOUR']
# select = select + ['TOTAL']
select2 = select2 + ['L\'OREAL']
# select = select + ['VALLOUREC']
select2 = select2 + ['ACCOR']
select2 = select2 + ['LAFARGE']
select2 = select2 + ['SANOFI-AVENTIS']
select2 = select2 + ['AXA']
# select = select + ['GROUPE DANONE']
# select = select + ['PERNOD-RICARD']
select2 = select2 + ['MICHELIN']
select2 = select2 + ['PEUGEOT SA']
# select = select + ['ESSILOR INTL']
select2 = select2 + ['SCHNEIDER ELECTRIC']
select2 = select2 + ['VEOLIA ENVIRON']
select2 = select2 + ['UNIBAIL-RODAMCO']
select2 = select2 + ['SAINT-GOBAIN']
select2 = select2 + ['CAP GEMINI']
# select = select + ['VINCI']
select2 = select2 + ['STMICROELECTRONICS']
select2 = select2 + ['ALCATEL LUCENT']
select2 = select2 + ['LAGARDERE SCA']
select2 = select2 + ['SOCIETE GENERALE A']
select2 = select2 + ['FRANCE TELECOM']
# select = select + ['ALSTOM']
# select = select + ['EDF']
# select = select + ['ARCELORMITTAL']

def inser(x,pop):
  if len(pop)<1:
    return [x]
  if x[0] >= pop[0][0]:
    return [x]+pop
  return [pop[0]] + inser(x, pop[1:len(pop)])

def tripop (pop):
  pop1 = []
  for x in pop:
    pop1 = inser(x,pop1)
  return pop1

def comb(x,y,param):
  if (param[4] != 0) and (x == y):
    return [uniform(-1.0,1.0) for i in range(len(x))]
  z = [0 for i in x]
  b = uniform(0.0,1.0)
  if b > param[5]:
    for i in range(len(x)):
      b = randint(0,1)
      if b == 0:
        z[i] = x[i]
      else:
        z[i] = y[i]
  else:
    for i in range(len(x)):
      z[i] = (x[i] + y[i]) / 2.0
  b = uniform(0.0,1.0)
  if b < param[6]:
    i = randint(0,len(z)-1)
    z[i] = uniform(-1.0, 1.0)
  return z
  
def evol(pop,param):
  pop = tripop(pop)
  pop = pop[0:param[1]]
  i = randint(0,param[1]-1)
  j = randint(0,param[1]-1)
  x = pop[i][1]
  y = pop[j][1]
  z = comb(x,y,param)
  v = valeur(z)
  print 'valeur = ',v
  pop = inser([v,z],pop)
  pop = pop[0:param[1]]
  f = open('pop.txt', 'w')
  writex(f,pop[0])
  f.write('\n')
  f.write(str(pop))
  f.close()
  return pop
  
def evolc (pop,param,c):
  pop = tripop(pop)
  pop = pop[0:param[1]]
  i = randint(0,param[1]-1)
  j = randint(0,param[1]-1)
  x = pop[i][1]
  y = pop[j][1]
  z = comb(x,y,param)
  v = valeurc(z,c)
  print 'valeur = ',v
  pop = inser([v,z],pop)
  pop = pop[0:param[1]]
  f = open('pop.py', 'w')
  writex(f,pop[0])
  f.write('\n')
  f.write ('pop = ')
  f.write(str(pop))
  f.close()
  return pop
  
def evolctv (pop,param,c,t):
  pop = tripop(pop)
  pop = pop[0:param[1]]
  i = randint(0,param[1]-1)
  j = randint(0,param[1]-1)
  x = pop[i][1]
  y = pop[j][1]
  z = combtv(x,y,param,t)
  v = valeurc(z,c)
  print 'valeur = ',v
  pop = inser([v,z],pop)
  pop = pop[0:param[1]]
  f = open('pop.py', 'w')
  writex(f,pop[0])
  f.write('\n')
  f.write('pop = ')
  f.write(str(pop))
  f.close()
  # fpops = open('pops.txt','a')
  # writex(fpops,pop[0])
  # fpops.write('\n')
  # fpops.write(str(pop))
  # fpops.close()
  fb = open('evolctv.txt','a')
  fb.write(" t=%d : %8.3f %8.3lf " % (t,pop[0][0],v))
  fb.write(str(pop[0][1]))
  fb.write(' ')
  fb.write(str(z))
  fb.write('\n')
  fb.close()
  return pop
  
def repevol1(pop,param):
  # pop = popinit(heur)
  i = 0
  while 1:
    i=i+1
    print ' '
    print 'i=', i, ' v=', pop[0][0]
    pop = evol(pop,param)

def repevol(pop,param):
  f = open('repevol.txt','a')
  # pop = popinit(heur,param)
  pop = pop[0:param[1]]
  print "l0=%7.1f seed(%d) maxi=%d testegal=%d pmoy=%.2f pmut=%.2f : " % (param[7], param[0], param[1], param[4], param[5], param[6]),
  # f.write ("l0=%7.1f seed(%d) maxi=%d te=%d pmoy=%.2f pmut=%.2f : " % (param[7], param[0], param[1], param[4], param[5], param[6]))
  f.write ("%d %d %d %.2f %.2f : " % (param[0], param[1], param[4], param[5], param[6]))
  # l0 = param[7]
  seed(param[0])
  t = 0
  while t<=param[2]:
    print 't=', t, ' v=', pop[0][0]
    pop = evol(pop,param)
    if t % param[3] == 0:
      print "*** %6.1f ***" % pop[0][0]
      f.write("%6.1f " % pop[0][0])
    t = t + 1
  print ''
  f.write('\n')
  f.close()

def repevolc(pop,param,c):
  f = open('repevolc.txt','a')
  # pop = popinit(heur,param)
  pop = pop[0:param[1]]
  print "l0=%7.1f seed(%d) maxi=%d testegal=%d pmoy=%.2f pmut=%.2f : " % (param[7], param[0], param[1], param[4], param[5], param[6]),
  # f.write ("l0=%7.1f seed(%d) maxi=%d te=%d pmoy=%.2f pmut=%.2f : " % (param[7], param[0], param[1], param[4], param[5], param[6]))
  f.write ("%d %d %d %.2f %.2f : " % (param[0], param[1], param[4], param[5], param[6]))
  # l0 = param[7]
  seed(param[0])
  t = 0
  while t<=param[2]:
    print 't=', t, ' v=', pop[0][0]
    pop = evolc(pop,param,c)
    if t % param[3] == 0:
      print "*** %6.1f ***" % pop[0][0]
      f.write("%6.1f " % pop[0][0])
    t = t + 1
  print ''
  f.write('\n')
  f.close()

def repevolcv(pop,param,c):
  f = open('repevolcv.txt','a')
  # pop = popinit(heur,param)
  pop = pop[0:param[1]]
  print "l0=%7.1f seed(%d) maxi=%d testegal=%d pmoy=%.2f pmut=%.2f : " % (param[7], param[0], param[1], param[4], param[5], param[6]),
  # f.write ("l0=%7.1f seed(%d) maxi=%d te=%d pmoy=%.2f pmut=%.2f : " % (param[7], param[0], param[1], param[4], param[5], param[6]))
  f.write ("%d %d %d %.2f %.2f %.2f %.2f : " % (param[0], param[1], param[4], param[5], param[8], param[9], param[10]))
  # l0 = param[7]
  if param[0] != 0:
    seed(param[0])
  t = 0
  while t<=param[2]:
    print 't=', t, ' v=', pop[0][0], '\t',
    pop = evolctv(pop,param,c,t)
    if t % param[3] == 0:
      print "*** %6.1f ***" % pop[0][0]
      f.write("%6.1f " % pop[0][0])
      # fb = open('repevolcvb.txt','a')
      # fb.write(" t=%d : %8.3f " % (t,pop[0][0]))
      # fb.write(pop[0][1])
      # fb.close()
    t = t + 1
  print ''
  f.write('\n')
  f.close()
  return pop

exparam1 = [26, 32, 100, 10, 1, 0.1, 0.25, 1000.0, 1.0, 1.0, 1.0, 1.0, 0.1, 50.0]

exparam = [26, 16, 200, 50, 1, 0.1, 0.25, 1000.0, 1.0, 1.0, 1.0, 1.0, 0.1, 50.0]

paramopt = [26, 32, 30000, 100, 1, 0.4, 0.25, 1000.0, 1.0, 1.0, 1.0, 1.0, 0.1, 50.0, 1.0]
paramopt10000 = [26, 32, 10000, 100, 1, 0.4, 0.25, 1000.0, 1.0, 1.0, 1.0, 1.0, 0.1, 50.0, 1.0]
paramopt1 = [26, 32, 100, 10, 1, 0.4, 0.25, 1000.0, 1.0, 1.0, 1.0, 1.0, 0.1, 50.0]
paramopt12 = [26, 8, 4, 1, 1, 0.4, 0.25, 1000.0, 1.0, 1.0, 1.0, 1.0, 0.1, 50.0]
paramopt500 = [26, 32, 500, 10, 1, 0.4, 0.25, 1000.0, 1.0, 1.0, 1.0, 1.0, 0.1, 50.0]
paramopt2 = [31, 48, 30000, 100, 1, 0.5, 0.25, 1000.0, 1.0, 1.03, 1.0, 1.0, 0.1, 50.0]
paramopt3 = [0, 48, 30000, 100, 1, 0.5, 0.25, 1000.0, 1.0, 1.03, 1.0, 1.0, 0.1, 50.0]

def testparam(pop):
  # f = open ('testparam.txt', 'w')
  # for l in [500, 1000, 2000]:
  l = 1000.0
  for maxi in [24, 48, 96]:
      for testegal in [0, 1]:
        for pmoy in [0.1, 0.5, 0.9]:
          for pmut in [0.1, 0.5, 0.9]:
           for s in [26, 31]:
            param = [s, maxi, 500, 100, testegal, pmoy, pmut, l]
            repevol(pop,param)
  # f.close()

def selectc(s,c):
  return [coursval(c,t) for t in s]

def defcours():
  global cours, cours_2, c1, c2, cours_3, c3, titres, c1d, c2d, c1dn, c2dn, c1n, c2n, c1nd, c2nd
  if site == 'lifebook':
    cours=lirecourslf(lnfxp)
    cours_2 = lirecourslf(lnfxp2)
    c1 = selectc (select, cours)
    c2 = selectc (select2, cours_2)
    cours_3 = lirecourslf (lnfxp[1:len(lnfxp)])
    cours_avril = lirecourslf ([dircoursxp + 'srd-0904.xls'])
  elif site == 'samsung':
    cours=lirecourslf(lnfs)
    cours_2 = lirecourslf(lnfs2)
    c1 = selectc (select, cours)
    c2 = selectc (select2, cours_2)
    cours_3 = lirecourslf (lnfs[1:len(lnfs)])
    cours_avril = lirecourslf ([dircourss + 'srd-0904.xls'])
  c3 = selectc (select2, cours_3)
  titres = [a[0][1] for a in cours]
  seed(26)
  c1d = decal(c1,300)
  c2d = decal(c2,300)
  c1dn = normcours(c1d)
  c2dn = normcours(c2d)
  c1n = normcours(c1)
  c2n = normcours(c2)
  c1nd = decal(c1n,300)
  c2nd = decal(c2n,300)

def testparamc(pop):
  # f = open ('testparamc.txt', 'w')
  # for l in [500, 1000, 2000]:
  l = 1000.0
  for maxi in [48, 96, 24]:
      for testegal in [0, 1]:
        for pmoy in [0.1, 0.5, 0.9]:
          for pmut in [0.1, 0.5, 0.9]:
           for s in [26, 31]:
            for c in [c2,c1]:
             param = [s, maxi, 500, 100, testegal, pmoy, pmut, l]
             repevolc(pop,param,c)
  # f.close()


def testparamcv(pop):
  # f = open ('testparamc.txt', 'w')
  # for l in [500, 1000, 2000]:
  l = 1000.0
  c = c1
  sigma = 0.1
  tau = 100.0
  for maxi in [24, 48, 96]:
      for testegal in [0, 1]:
        for pmoy in [0.1, 0.5, 0.9]:
          for pmut in [1.0, 2.0]:
           for pvar in [1.0, 2.0]:
            for pcxy in [1.0, 2.0]:
             for s in [26, 31]:
              # for c in [c2,c1]:
               param = [s, maxi, 200, 50, testegal, pmoy, 0.0, l, pmut, pvar, pcxy, 0, sigma, tau]
               repevolcv(pop,param,c)
  # f.close()

# cours_avril = lirecourslf ([dircoursxp + 'srd-0904.xls'])

def hausse_avril(t):
  for a in cours_avril:
    if a[0][1].find(t) == 0:
      return (a[len(a)-1][6] - a[0][6]) / a[0][6]
  return 0.0

def signal (x, titre):
  p = qimt(x)
  kds = calculind3 (coursval(cours,titre), p)
  return kds[2]  

achete = ['ALTEN','BOURBON','CHRISTIAN DIOR','EURAZEO','LVMH','NEXITY','SECHILIENNE','VINCI']

# titres = [a[0][1] for a in cours]

def writesignal(x):
  a = []
  f = open('signal.txt','w')
  for t in titres:
    s = signal(x,t)
    h = hausse_avril(t)
    print s, ' \t ', h, ' \t ', t
    f.write (str(s) + ' \t ' + str(h) + ' \t ' + t + '\n')
    a = a + [[s,h]]
  f.close()
  graphxy(a,600,600)
  return a

def printx(x):
  print 'valeur: ',x[0]
  qm = qimt(x[1])
  print 'qi = ', 
  for a in qm[0]:
    print "%6.3f" % a,
  print '\nmt = '
  for a in qm[1]:
    for b in a:
      print "%6.3f" % b,
    print ''

def printpop(p):
  for x in p:
    print ''
    printx(x)

def writex(fd,x):
  fd.write( '# valeur: '+str(x[0])+'\n')
  qm = qimt(x[1])
  fd.write( '# qi = ')
  for a in qm[0]:
    fd.write(" %6.3f" % a)
  fd.write( '\n# mt = \n# ' )
  for a in qm[1]:
    for b in a:
      fd.write( " %6.3f" % b )
    fd.write('\n# ')

def writepop(fn,pop):
  fd=open(fn,'w')
  for x in pop:
    fd.write('\n')
    writex(fd,x)

# execfile('load.py')
# execfile('exbourse.py')
# execfile('evol.py')
# execfile('combtv.py')
# execfile('combtvgc.py')
# l0=1000
# p0=popinit(heur,300)
# repevolcv(p0,paramopt,c1)
# testparam(p0)
# execfile('evoln.py')
# repevoln(p0,paramopt,c1)
# execfile('decal.py')
# seed(26)
# c1d = decal(c1,300)
# execfile('normcours.py')
# c1dn = normcours(c1d)
# repevolcv(p0,paramopt,c1dn)
# p1=p0+[vecteurqimt(qi3macd,mt3macd(12,26,9))]
# execfile('repar.py')
# p0r=popinit(heur,300)
# p1r=p0r+[[50.0]+vecteurqimt(qi3macd,mt3macd(12,26,9))] # repar
# c1n=normcours(c1)
# repevolcv(p1r,paramopt,c1n)
# execfile('convertxnq.py')
# p5=popinit(heur,300)
# p5m=p5+[convertxnq(vecteurqimt(qi3macd,mt3macd(12,26,9)),4,5)]
# execfile('pop-20000.py')
# p5n=p5m+[convertxnq(pop[0][1],4,5)]
# repevolcv(p5n,paramopt,c1dn)
# p0=popinitc(heur,300,c1dn)
# p0=popinitcnq(heur,300,c1dn,5)




