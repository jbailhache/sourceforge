
cours1 = lirecourslf(lnfxp[0:3])
cours2 = lirecourslf(lnfxp[3:6])
cours3 = lirecourslf(lnfxp[6:9])

c1 = coursval(cours3,'PPR')
c2 = coursval(cours3,'AXA')
c3 = coursval(cours3,'HERMES')

lc = [c1,c2,c3]

