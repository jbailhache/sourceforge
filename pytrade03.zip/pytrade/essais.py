
afc=1
mme(coursval(cours,'ALTEN'),14)

afc=0
moyind(select,mme,14)

tranche3(lc4)
