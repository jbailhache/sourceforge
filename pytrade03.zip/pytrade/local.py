
site='samsung'
