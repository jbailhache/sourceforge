PocketGCC 1.50 (08.11.03)

Please visit http://mifki.ru/pocketgcc for installation instructions, documentation and updates!