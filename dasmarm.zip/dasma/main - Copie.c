/****************************************************************************
 *                                                                          *
 * File    : main.c                                                         *
 *                                                                          *
 * Purpose : Generic Pocket PC application.                                 *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

#define UNICODE
#include <windows.h>
#include <windowsx.h>
#include <aygshell.h>
#include "main.h"

#include <stdio.h>

// #define DASMAS

#define NELEMS(a)  (sizeof(a) / sizeof((a)[0]))

/** Prototypes **************************************************************/

static LRESULT WINAPI MainWndProc(HWND, UINT, WPARAM, LPARAM);
static BOOL Main_OnCreate(HWND, CREATESTRUCT *);
static void Main_OnActivate(HWND, UINT, HWND, BOOL);
static void Main_OnSettingChange(HWND, UINT, PCTSTR);
static void Main_OnPaint(HWND);
static void Main_OnCommand(HWND, int, HWND, UINT);
static void Main_OnDestroy(HWND);
static LRESULT WINAPI AboutDlgProc(HWND, UINT, WPARAM, LPARAM);

/** Global variables ********************************************************/


FILE *gfdasm;

int dasm = 1;

struct
{
	int (*ptr)();
	char *name;
} tabf[1000];

int nf=0;

struct
{
	int adr;
	char *name;
} tabadr[1000];

int nadr = 0;

FILE *fdasm;

union
{
	void *p[0x100];
	int (*(f[0x100])) ();
} ulabels;

// void **labels = ulabels.p;

/*** prog ***/

char filename[] = "\\Carte de stockage\\test\\out.txt";
char mode[] = "w";
short align1 = 0;
char text[] = "resultat=%X.\n";
int align2 = 0;
wchar_t utext[] = L"unicode";
char enddataprog[] = "$$$";

int calcul (int a, int b)
{
	if (a > b)
		return a + (b << 1);
		// return a / b;
	else
		return a + b;
		// return a * b;
}	

int prog (int x) 
{
	FILE *f;
	f = fopen (filename, mode);
	fprintf (f, text, calcul (4, 5));
	fclose (f);
}

int endprog (int x)
{
	return x;
}

/*** win ***/

static HANDLE ghInstance;
static HWND ghwndMB;
static SHACTIVATEINFO gsai = { sizeof(SHACTIVATEINFO) };

static LRESULT CALLBACK testwinproc (HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	SHMENUBARINFO mbi;

	switch (msg)
	{
		case WM_CREATE:
    memset(&mbi, 0, sizeof(mbi));
    mbi.cbSize = sizeof(mbi);
    mbi.hwndParent = hwnd;
    mbi.nToolBarId = IDR_MNU_MAIN;
    mbi.hInstRes = ghInstance;
    mbi.nBmpId = 0;
    mbi.cBmpImages = 0;
    if (!SHCreateMenuBar(&mbi))  /* create the menu bar */
        return FALSE;

    ghwndMB = mbi.hwndMB;

    return TRUE;

			break;
		case WM_ACTIVATE:

	SHHandleWMActivate(hwnd, MAKEWPARAM(state,fMinimized), (LPARAM)hwndActDeact, &gsai, 0);

			break;
		case WM_SETTINGCHANGE:

			break;
		case WM_PAINT:

			break;
		case WM_COMMAND:

			break;
		case WM_DESTROY:

			break;
		default:
            		return DefWindowProc(hwnd, msg, wParam, lParam);

	}
}

int PASCAL testwin (HINSTANCE hInstance, HINSTANCE hPrevInstance, LPWSTR lpszCmdLine, int nCmdShow)
{
    HWND hwnd;
    MSG msg;

    /* Always check first if program is already running */
    hwnd = FindWindow(L"testwinClass", NULL);
    if (hwnd)
    {
        /*
         * Set focus to the foremost child window. The "|0x01" is used to
         * bring any owned windows to the foreground and activate them.
         */
        SetForegroundWindow((HWND)((ULONG)hwnd|0x00000001));
        return 0;
    }

    if (!hPrevInstance)
    {
        WNDCLASS wc;

        wc.lpszClassName = L"testwinClass";
        wc.lpfnWndProc = testwinproc;
        wc.style = CS_VREDRAW|CS_HREDRAW;
        wc.hInstance = hInstance;
        wc.hIcon = NULL;
        wc.hCursor = NULL;
        wc.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
        wc.lpszMenuName = NULL;
        wc.cbClsExtra = 0;
        wc.cbWndExtra = 0;

        if (!RegisterClass(&wc))
            return 1;
    }

    ghInstance = hInstance;

    hwnd = CreateWindowEx(
        0,
        L"testwinClass",
        L"testwin Program",
        WS_VISIBLE|WS_SYSMENU,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        NULL,
        NULL,
        hInstance,
        NULL
    );
    if (!hwnd) return 1;

    /*
     * When CW_USEDEFAULT is used to create the main window, the height of the
     * menu bar is not considered. We must manually reserve space for the menu.
     */
    if (ghwndMB)
    {
        RECT rcWin, rcMB;

        GetWindowRect(hwnd, &rcWin);
        GetWindowRect(ghwndMB, &rcMB);
        rcWin.bottom -= (rcMB.bottom - rcMB.top);
        MoveWindow(hwnd, rcWin.left, rcWin.top, rcWin.right - rcWin.left, rcWin.bottom - rcWin.top, FALSE);
    }

	hEdit1 = CreateWindow (	
		L"EDIT", L"", 
		WS_VISIBLE|WS_CHILD|WS_BORDER|WS_VSCROLL|WS_HSCROLL|
		ES_MULTILINE|ES_WANTRETURN|ES_AUTOHSCROLL|ES_AUTOVSCROLL,
		// 10, 10, 300, 60,
		// 10, 1, 300, 80,
		left, yedit1, right-left, hedit1,
		hwnd, NULL, ghInstance, NULL);

	hButton1 = CreateWindow (
	L"BUTTON", L"OK",
		WS_CHILD | WS_VISIBLE | ES_LEFT | WS_BORDER,
		// 260, 80, 40, 20,
		// 260, 83, 40, 18,
		xbutton1, top, wbutton1, hedit2,
		hwnd, NULL, ghInstance, NULL);

    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    while (GetMessage(&msg, NULL, 0, 0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return msg.wParam;
}



/*** loadasm ***/

FILE *out;

#define CODESIZE 0x70000
unsigned int code[CODESIZE];
int adr;

#define NLABELS 0x2000
#define LEN 0x20
struct
{
	char name[LEN];
	unsigned int value;
} labels[NLABELS];
int nl;

char str[1000];

int endvar;

#define DL(xxx) strncpy(labels[nl].name, #xxx, LEN); labels[nl].value = (int)xxx; nl++;

int divide (int a, int b)
{
	return a / b;
}

int modulo (int a, int b)
{
	return a % b;
}


int match (unsigned int x, unsigned int pattern, unsigned int mask)
{
	return ((x & mask) == (pattern & mask));
}

void initf (void)
{
		DL(fopen)
		DL(fclose)
		DL(fprintf)
		DL(divide)
		DL(modulo)
		DL(match)
		DL(fscanf)
		DL(fgets)
		DL(feof)
		DL(sprintf)
		DL(sscanf)
		DL(strcmp)
		DL(strncmp)
		DL(strcpy)
		DL(strncpy)
		DL(strlen)


}

int isd (char c)
{
	if (c>= '0' && c <= '9')
		return 1;
	if (c>='A' && c<='F')
		return 1;
	return 0;
}

unsigned int instrcode (char *opcode, int nargs, unsigned int args[], char *com, int adr)
{
	unsigned int x; int depl;
	int i;

	/*
	fprintf (out, "instrcode %X : <%s> ", adr, opcode);
	for (i=0; i<nargs; i++)
		fprintf (out, "%X ", args[i]);
	fprintf (out, "\n");
	*/

	if (!strcmp (opcode, "PUSHR"))
	{
		x = 0x92D0000 | 0x10000 * args[0] | args[1];
		// fprintf (out, "%X %X %X\n", args[0], 0x92D0000 | args[0], x);
	}
	else if (!strcmp (opcode, "POPR"))
		x = 0x8BD0000 | 0x10000 * args[0] | args[1];
	else if (!strcmp (opcode, "R=R"))
		x = 0x1A00000 | 0x1000 * args[0] | args[1];
	else if (!strcmp (opcode, "R=") && args[1]<0x100)
		x = 0x3A00000 | 0x1000 * args[0] | args[1];
	else if (!strcmp (opcode, "R=R+R"))
		x = 0x0800000 | 0x1000 * args[0] | 0x10000 * args[1] | args[2];
	else if (!strcmp (opcode, "R=R*R"))
		x = 0x0000090 | args[0] * 0x10000 | args[1] * 0x100 | args[2];
	else if (!strcmp (opcode, "R=R|R"))
		x = 0x1800000 | args[1] << 16 | args[0] << 12 | args[2];
	else if (!strcmp (opcode, "R=R+") && args[2] < 0x100)
		x = 0x2800000 | args[1] << 16 | args[0] << 12 | args[2];
	else if (!strcmp (opcode, "R=R|") && args[2] < 0x100)
		x = 0x3800000 | args[1] << 16 | args[0] << 12 | args[2];
	else if (!strcmp (opcode, "R=R->~") && args[2] < 0x100)
		x = 0x3E00000 | args[1] << 16 | args[0] << 12 | args[2];
	else if (!strcmp (opcode, "?=?-"))
		x = 0x1500000 | 0x1000 * args[0] | 0x10000 * args[1] | args[2];
	else if (!strcmp (opcode, "GOTO"))
	{
		depl = ((args[0] - (adr + 8)) >> 2) & 0xFFFFFF;
		x = 0xA000000 | depl;
	}
	else if (!strcmp (opcode, "()"))
	{
		depl = ((args[0] - (adr + 8)) >> 2) & 0xFFFFFF;
		x = 0xB000000 | depl;
	}
	else if (!strcmp (opcode, "R=[]"))
	{
		depl = (args[1] - (adr + 8)) & 0xFFF;
		x = 0x59F0000 | 0x1000 * args[0] | depl;
	}
	else if (!strcmp (opcode, "[]=R"))
	{
		depl = (args[0] - (adr + 8)) & 0xFFF;
		x = 0x58F0000 | 0x1000 * args[0] | depl;
	}
	else if (!strcmp (opcode, "R=[R+]"))
		x = 0x5900000 | 0x10000 * args[1] | 0x1000 * args[0] | args[2];
	else if (!strcmp (opcode, "[R+]=R"))
		x = 0x5800000 | 0x10000 * args[0] | 0x1000 * args[2] | args[1];

	else if (!strcmp (opcode, "[R+R<<]=R"))
		x = 0x7800000 | args[0] << 16 | args[3] << 12 | args[2] << 7 | args[1];

	else if (!strcmp (opcode, "RR#?=[R+]"))
		x = 0x8D00000 | args[1] << 16 | args[0];
	else if (!strcmp (opcode, "[R+]?=RR#"))
		x = 0x8C00000 | args[0] << 16 | args[1];

	else if (!strcmp (opcode, "R=+$[R+R]"))
		x = 0x19000D0 | args[1] << 16 | args[0] << 12 | args[2];
	else if (!strcmp (opcode, "+$[R+R]=R"))
		x = 0x18000D0 | args[0] << 16 | args[2] << 12 | args[1];
 
	else
		sscanf (com, "%X", &x);
	// fprintf (out, "instrcode = %07X\n", x);
	return x;
}

int asm (char *line, int adr)
{
	int lab, ch, d, i, k, adr1, call;
	unsigned int x, x1;
	char *com;
	union
	{
		int adr;
		char *pchar;
		unsigned int *puint;
	} u;
	char *cond[] = { "==", "!=", "c", "!c", "<0", ">=0",  "OVF", "!OVF", "HI", "LS", ">=", "<", ">", "<=", "", "UNC" };

	// fprintf (out, "asm %X <%s>\n", adr, line);

	adr1 = adr;
	call = 0;

	d = 0;
	lab = 0;
	ch = 0;
	for (i=0; line[i]; i++)
	{
		if (line[i] == ':')
		{
			lab = 1;
			d = i+1;
		}
		if (line[i] == '"')
			ch = 1;
	}

	// fprintf (out, "lab=%d ch=%d d=%d\n", lab, ch, d);

	if (ch)
	{
		// fprintf (out,"ch\n");
		for (i=d; line[i]!='"'; i++);
		for (k=i+1; line[k]!='"' && line[k]!=0; k++)
		{
			u.adr = adr++;
			*(u.pchar) = line[k];
		}
		u.adr = adr++;
		*(u.pchar) = 0;
		while (adr % 4)
		{
			u.adr = adr++;
			*(u.pchar) = 0;
		}
	}
	else
	{
		char op[LEN], condi[LEN];
		int condcode;
		char *opcode;
		int lop;
		char args[8][10];
		unsigned int argsn[8];
		int nargs, larg, i, k;
		// fprintf (out,"non ch\n");
		nargs = 0;
		lop = 0;
		larg = 0;
		// fprintf (out, "avant boucle\n");
		for (i=d; line[i]!=0 && line[i]!='\n' && line[i]!='\r' && line[i]!='%'; i++)
		{
			if (line[i] != ' ' && line[i]!='\t')
			{
				if (isd(line[i]))
				{
					for (k=0; isd(line[i+k]); k++)
						args[nargs][k] = line[i+k];
					args[nargs][k] = 0;
					nargs++;
					i += k-1;
				}
				else
				{
					op[lop++] = line[i];
				}
			}
		}
		op[lop] = 0;
		// fprintf (out, "op=<%s> %d args\n", op, nargs);

		if (line[i]=='%')
			com = line+i+1;
		else 
			com = "BADC0DE";

		for (i=0; i<nargs; i++)
		{
			sscanf (args[i], "%X", &(argsn[i]));
			// fprintf (out, "%d <%s> %X\n", i, args[i], argsn[i]);
		}

		opcode = op;
		strcpy (condi, "");
		condcode = 14;

		for (k=0; k<14; k++)
			if (!strncmp (op, cond[k], strlen(cond[k])))
			{
				strcpy (condi, cond[k]);
				condcode = k;
				opcode = op + strlen(cond[k]);
			}
		
		/*
		fprintf (out,"<cond:%s:%d><%s>", condi, condcode, opcode);
		for (k=0; k<nargs; k++)
			fprintf (out, "<%d:%s>", k, args[k]);
		fprintf (out, "\n");
		*/

		u.adr = adr;
		
		// fprintf (out, "test opcode\n");
		if (!*opcode)
		{
			// fprintf (out, "opcode vide\n");
			sscanf (args[0], "%X", &x);
			// fprintf (out, "arg=%X\n", x);
			*(u.puint) = x;
			// fprintf (out, "fin cas opcode vide\n");
			adr += 4;
		}		
		else if (!strcmp (opcode, "RS"))
		{
			adr += argsn[0];
		}
		else
		{
			// fprintf (out, "opcode non vide\n");
			// x = 0;
			x = instrcode (opcode, nargs, argsn, com, adr) | condcode * 0x10000000;
			// fprintf (out, "ecriture code %X %X %X\n", adr, u.puint, x);
			*(u.puint) = x;
			// fprintf (out, "fin cas opcode non vide\n");
			adr += 4;
		}

		sscanf (com, "%X", &x1);
		fprintf (out, "%X: %X", adr1, x);
		if (x != x1 && !match (x, 0xB000000, 0xF000000))
			fprintf (out, " *** different ***");
		fprintf (out, "\n\n");

		
	}
	// fprintf (out, "fin asm\n");
	return adr;


}

void substlabels (char *line, char *line1)
{
	int i, k, l, trouve;
	i = 0;
	k = 0;
	for (;;)
	{
		if (line[i] == 0)
		{
			line1[k] = 0;
			break;
		}
		trouve = 0;
		for (l=0; l<nl; l++)
		{
			// fprintf (out, "%d %d %d <%s> <%s>\n", i, k, l, labels[l].name, line+i);
			if (!strncmp (line+i, labels[l].name, strlen(labels[l].name)))
			{
				trouve = 1;
				sprintf (str, "pos %d %d label %d <%s>=%X\n", i, k, l, labels[l].name, labels[l].value);
				k += sprintf (line1+k, "%X", labels[l].value);
				i += strlen(labels[l].name);
				break;
			}
		}
		if (!trouve)
			line1[k++] = line[i++];
	}
	fprintf (out, "%s\n%s\n", line, line1); 
}

// int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPWSTR lpszCmdLine, int nCmdShow)

int callcode (FILE *fd)
{
	int r;
	union
	{
		unsigned int *ptr;
		int (*f) ();
	} u;
	u.ptr = code;
	// fprintf (out, "appel code...\n");
	r = (*(u.f))(fd);
	// fprintf (out, "resultat=%X\n", r);
	return r;
}

int loadasm (FILE *fd)
{
	FILE *fcode;
	char line[300];
	char line1[300];
	char name[LEN];
	int trouve, chaine, i, k;
	unsigned int x;
	int r;
	char *filename;
	int endcode;

	union
	{
		unsigned int *ptr;
		int (*f) ();
	} u;

	endcode = 0;
	nl = 0;
	initf ();

	/*
#ifdef DASMAS
	out = fopen ("\\Carte de stockage\\test\\loadasma.txt", "w");
#else
	out = fopen ("\\Carte de stockage\\test\\loadasm.txt", "w");
#endif
	*/

	out = fd;

	fprintf (out, "Debut\n");

#ifndef DASMAS
	filename = "\\Carte de stockage\\test\\dump.txt";
#else
	filename = "\\Carte de stockage\\test\\dasma.txt";
#endif
	fcode = fopen (filename, "r");
	if (fcode == NULL)
	{
		fprintf (out, "Erreur ouverture <%s>\n", filename);
		return 0;
	}
	fprintf (out, "Fichier ouvert\n");

	adr = (int) code;
	for (;;)
	{
		fgets (line, sizeof(line), fcode);
		if (feof(fcode))
			break;
		if (*line != 0 && *line != '\n' && *line != '\r' && *line != '%')
		{
			trouve = 0;
			chaine = 0;
			for (i=0; line[i]; i++)
			{
				if (line[i] == ':')
					trouve = 1;
				if (line[i] == '"')
					chaine = 1;
			}
			if (trouve)
			{
				k = 0;
				for (i=0; line[i]!=':'; i++)
				{
					if (line[i] == ',')
					{
						name[k] = 0;
						strncpy (labels[nl].name, name, LEN);
						labels[nl].value = adr;
						nl++;
						k = 0;
					}
					else
						name[k++] = line[i];
				}
				name[k] = 0;
				if (*name)
				{
					strncpy (labels[nl].name, name, LEN);
					labels[nl].value = adr;
					nl++;
				}
			}
			if (!chaine)
				// adr += 4;
			{
				int trouve = 0;
				for (i=0; line[i]!=0; i++)
				{
					if (!strncmp (line+i, "RS", 2))
					{
						trouve = 1;
						int taille;
						sscanf (line+i+2, "%X", &taille);
						adr += ((taille + 3) / 4) * 4;
						break;
					}
				}
				if (!trouve)
					adr += 4;
			}
			else /* chaine */
			{
				for (i=0; line[i]!='"'; i++);
				for (k=0; line[i+1+k]!='"' && line[i+1+k]!=0 && line[i+1+k]!='\n' && line[i+1+k]!='\r'; k++);
				fprintf (out, "<k=%d>",k);
				adr += ((k + 4) / 4 ) * 4;
			}
		}
	}
	fclose(fcode);

	for (i=0; i<nl; i++)
		fprintf (out, "%s=%X\n", labels[i].name, labels[i].value);

	fcode = fopen (filename, "r");
	if (fcode == NULL)
	{
		fprintf (out, "Erreur 2eme ouverture <%s>\n",filename);
		return 0;
	}
	fprintf (out, "Fichier ouvert\n");

	adr = (int) code;
	for (;;)
	{
		fgets (line, sizeof(line), fcode);
		if (feof(fcode))
			break;
		line[strlen(line)-1] = 0;
		if (*line!=0 && *line != '\n' && *line != '\r')
		{
			substlabels (line, line1);
			adr = asm (line1, adr);
		}
	}

	// for (i=0; i<=(adr-(int)code)/4; i++)
	for (i=0; i<=endcode; i++)
		fprintf (out, "%X: %08X\n", &(code[i]), code[i]);

	fprintf (out, "appel code...\n");
	r = callcode (fd);
	fprintf (out, "resultat=%X\n", r);

	fclose(out);
}

int start (FILE *fd)
{
	gfdasm = fd;
	fprintf (fd, "start\n");
	loadasm(fd);
}

int endstart () { return 0; }

/******/


unsigned int field (unsigned int x, unsigned int mask)
{
	while ((mask & 1) == 0)
	{
		mask = mask >> 1;
		x = x >> 1;
	}
	return x & mask;
}

int sfield (unsigned int x, unsigned int mask)
{
	unsigned int sp, s;
	while ((mask & 1) == 0)
	{
		mask = mask >> 1;
		x = x >> 1;
	}
	sp = (mask+1)>>1;
	s = x & sp;
	if (s == 0)
		return x & mask;
	else
		// return -((~(x & mask)) + 1);
		return (x & mask) | ~mask;
}

unsigned int rotate (unsigned int x, unsigned int r)
{
	return (x>>r) | (x<<(32-r));
}

void printasm (FILE *out, unsigned int x, unsigned int adr)
{
	char buf[1000];
	int i, j;
	char *cond[] = { "==", "!=", "c", "!c", "<0", ">=0",  "OVF", "!OVF", "HI", "LS", ">=", "<", ">", "<=", "", "UNC" };
	char *op[] = { "&", "!", "-", "*-1+", "+", "+c+", "-!c-", "*-1-!c+", "?&", "?!", "?-", "?+", "|", "->", "&!", "->~" };
	// char *shift[] = { "LSL", "LSR", "ASR",  "RR" };
	char *shift[] = { "<<", ">>", "->>", ">>>" };
	unsigned int Rn, Rd, Rs, Rm;
	unsigned int adr1;
	int adrinstr;
	int trouve;

	adrinstr = adr;

	Rn = field (x, 0xF0000);
	Rd = field (x, 0xF000);
	Rs = field (x, 0xF00);
	Rm = field (x, 0xF);

	i = 0;

	for (j=0; j<nadr; j++)
		if (x == tabadr[j].adr)
		{
			if (dasm)
			{
				i += sprintf (buf+i, "%s", tabadr[j].name);
				goto outbuf;
			}
			else
				i += sprintf (buf+i, "#%X == %s ", x, tabadr[j].name);
		}

	i += sprintf (buf+i, cond[x>>28]);
	// i += sprintf (buf+i, "(%x)", x>>28);
	i += sprintf (buf+i, " ");

	if (match (x, 0x1200010, 0xFF000F0))
		i += sprintf (buf+i, "BX [R%X]", Rm);

	else if (match (x, 0xF0000000, 0xF0000000)) /* unconditional */
		i += sprintf (buf+i, "#%07X", x & 0xFFFFFFF);

	/*
	else if (match (x, 0xA000000, 0xF000000))
		i += sprintf (buf+i, "B RF+4*%X == %X", field (x, 0xFFFFFF), adr+8+4*sfield(x,0xFFFFFF));
	*/
	else if (match (x, 0xA000000, 0xF000000))
	{
		// i += sprintf (buf+i, "BL RF+4*%X == %X",  field (x, 0xFFFFFF), adr+8+4*sfield(x,0xFFFFFF));
		trouve = 0;
		for (j=0; j<nadr; j++)
			if ((int)(tabadr[j].adr) == adr+8+4*sfield(x,0xFFFFFF))
			{
				trouve = 1;
				i += sprintf (buf+i, "GOTO %s", tabadr[j].name);
			}
		if (!trouve)
			i += sprintf (buf+i, "GOTO %X", adr+8+4*sfield(x,0xFFFFFF));
	}

	else if (match (x, 0xB000000, 0xF000000))
	{
		// i += sprintf (buf+i, "BL RF+4*%X == %X",  field (x, 0xFFFFFF), adr+8+4*sfield(x,0xFFFFFF));
		trouve = 0;
		for (j=0; j<nadr; j++)
			if ((int)(tabadr[j].adr) == adr+8+4*sfield(x,0xFFFFFF))
			{
				trouve = 1;
				i += sprintf (buf+i, "%s ()", tabadr[j].name);
			}
		if (!trouve)
			i += sprintf (buf+i, "%X ()", adr+8+4*sfield(x,0xFFFFFF));
	}
	else if (match (x, 0x1000000, 0xF900010)) /* misc */
		// i += sprintf (buf+i, "#%07X misc", x & 0xFFFFFFF);
		i += sprintf (buf, "%X", x);
	else if (match (x, 0x1000010, 0xF900090)) /* misc */
		// i += sprintf (buf+i, "#%07X misc", x & 0xFFFFFFF);
		i += sprintf (buf, "%X", x);

	/*
	else if (match (x, 0x3A00000, 0xFFF0F00))
		i += sprintf (buf+i, "R%X=%X", field (x, 0xF000), field (x, 0xFF));
	else if (match (x, 0x1A00000, 0xFFF0FF0))
		i += sprintf (buf+i, "R%X=R%X", field (x, 0xF000), field (x, 0xF));
	else if (match (x, 0x2800000, 0xFF00F00))
		i += sprintf (buf+i, "R%X=R%X+%X", field (x, 0xF000), field (x, 0xF0000), field (x, 0xFF));
	else if (match (x, 0x0800000, 0xFF00FF0))
		i += sprintf (buf+i, "R%X=R%X+R%X", field (x, 0xF000), field (x, 0xF0000), field (x, 0xF));
	else if (match (x, 0x2400000, 0xFF00F00))
		i += sprintf (buf+i, "R%X=R%X-%X", field (x, 0xF000), field (x, 0xF0000), field (x, 0xFF));
	else if (match (x, 0x0400000, 0xFF00FF0))
		i += sprintf (buf+i, "R%X=R%X-R%X", field (x, 0xF000), field (x, 0xF0000), field (x, 0xF));
	
	else if (match (x, 0x5900000, 0xFF00000))
		i += sprintf (buf+i, "R%X=[R%X+%X]", field (x, 0xF000), field (x, 0xF0000), field (x, 0xFFF));
	else if (match (x, 0x5800000, 0xFF00000))
		i += sprintf (buf+i, "[R%X+%X]=R%X", field (x, 0xF0000), field (x, 0xFFF), field (x, 0xF000));
	*/

	else if (match (x, 0x9200000, 0xFF00000))
		i += sprintf (buf+i, "PUSH R%X %04X", field (x, 0xF0000), field (x, 0xFFFF));
	else if (match (x, 0x8B00000, 0xFF00000))
		i += sprintf (buf+i, "POP R%X %04X", field (x, 0xF0000), field (x, 0xFFFF));

	else if (match (x, 0x1A00000, 0xFF00FF0)) /* move with register */
		i += sprintf (buf+i, "R%X = R%X", Rd, Rm);
	else if (match (x, 0x1B00000, 0xFF00010)) /* move with register, update condition codes */
		i += sprintf (buf+i, "R%X ?= R%X", Rd, Rm);

	else if (match (x, 0x1A00000, 0xFF00010)) /* move with register shifted by immediate */
		i += sprintf (buf+i, "R%X = R%X %s %X", Rd, Rm, shift[field(x,0x60)], field(x,0xF80));
	else if (match (x, 0x1B00000, 0xFF00010)) /* move with register shifted by immediate, update condition codes */
		i += sprintf (buf+i, "R%X ?= R%X %s %X", Rd, Rm, shift[field(x,0x60)], field(x,0xF80));
	else if (match (x, 0x1A00010, 0xFF00090)) /* move with register shifted by register */
		i += sprintf (buf+i, "R%X = R%X %s R%X", Rd, Rm, shift[field(x,0x60)], Rs);
	else if (match (x, 0x1B00010, 0xFF00090)) /* move with register shifted by register, update condition codes */
		i += sprintf (buf+i, "R%X ?= R%X %s R%X", Rd, Rm, shift[field(x,0x60)], Rs);
	else if (match (x, 0x3A00000, 0xFF00000)) /* move immediate */
		i += sprintf (buf+i, "R%X = %X", Rd, rotate (field(x,0xFF), field(x,0xF00)));
	else if (match (x, 0x3B00000, 0xFF00000)) /* move immediate, update condition codes */
		i += sprintf (buf+i, "R%X ?= %X", Rd, rotate (field(x,0xFF), field(x,0xF00)));

	else if (match (x, 0x0000000, 0xE100FF0)) /* data processing with register */
		i += sprintf (buf+i, "R%X = R%X %s R%X", Rd, Rn, op[field(x,0x1E00000)], Rm);
	else if (match (x, 0x0100000, 0xE100FF0)) /* data processing with register, update condition codes */
		i += sprintf (buf+i, "R%X ?= R%X %s R%X", Rd, Rn, op[field(x,0x1E00000)], Rm);

	else if (match (x, 0x0000000, 0xE100010)) /* data processing with register shifted by immediate */
		i += sprintf (buf+i, "R%X = R%X %s R%X %s %X", Rd, Rn, op[field(x,0x1E00000)], Rm, shift[field(x,0x60)], field(x,0xF80));
	else if (match (x, 0x0100000, 0xE100010)) /* data processing with register shifted by immediate, update condition codes */
		i += sprintf (buf+i, "R%X ?= R%X %s R%X %s %X", Rd, Rn, op[field(x,0x1E00000)], Rm, shift[field(x,0x60)], field(x,0xF80));
	else if (match (x, 0x0000010, 0xE100090)) /* data processing with register shifted by register */
		i += sprintf (buf+i, "R%X = R%X %s R%X %s R%X", Rd, Rn, op[field(x,0x1E00000)], Rm, shift[field(x,0x60)], Rs);
	else if (match (x, 0x0100010, 0xE100090)) /* data processing with register shifted by register, update condition codes */
		i += sprintf (buf+i, "R%X ?= R%X %s R%X %s R%X", Rd, Rn, op[field(x,0x1E00000)], Rm, shift[field(x,0x60)], Rs);
	else if (match (x, 0x2000000, 0xE100000)) /* data processing immediate */
		i += sprintf (buf+i, "R%X = R%X %s %X", Rd, Rn, op[field(x,0x1E00000)], rotate (field(x,0xFF), field(x,0xF00)));
	else if (match (x, 0x2100000, 0xE100000)) /* data processing immediate, update condition codes */
		i += sprintf (buf+i, "R%X ?= R%X %s %X", Rd, Rn, op[field(x,0x1E00000)], rotate (field(x,0xFF), field(x,0xF00)));

	else if (match (x, 0x4000000, 0xE000000)) /* load store immediate offset */
	{
		char s;
		char *af;
		char adr[30];
		char mem[30];
		unsigned int im;
		if (x & 0x800000)
			s = '+';
		else
			s = '-';
		im = field(x,0xFFF);
		if (match (x, 0x4000000, 0xF200000))
		{
			af = "=";
			sprintf (adr, "R%X,%c=%X", Rn, s, im);
		}
		else if (match (x, 0x4200000, 0xF200000))
		{
			af = "=U";
			sprintf (adr, "R%X,%c=%X", Rn, s, im);
		}
		else if (match (x, 0x5000000, 0xF200000))
		{
			af = "=";
			sprintf (adr, "R%X%c%X", Rn, s, im);
			if (Rn == 0xF)
			{ 
				if (s == '+')
					adr1 = adrinstr + 8 + im;
				else
					adr1 = adrinstr + 8 - im;
				if (dasm)
					sprintf (adr, "%X", adr1);
				else
					sprintf (adr+strlen(adr), "==%X", adr1);
				for (j=0; j<nadr; j++)
					if (adr1 == tabadr[j].adr)
					{
						if (dasm)
							sprintf (adr, "%s", tabadr[j].name);
						else
							sprintf (adr+strlen(adr), "==%s", tabadr[j].name);
					}
					
			}
		}
		else if (match (x, 0x5200000, 0xF200000))
		{
			af = "=";
			sprintf (adr, "R%X%c=%X", Rn, s, im);
		}
		if (x & 0x400000)
			sprintf (mem, "$[%s]", adr);
		else
			sprintf (mem, "[%s]", adr);
		if (x & 0x100000)
			i += sprintf (buf+i, "R%X %s %s", Rd, af, mem);
		else
			i += sprintf (buf+i, "%s %s R%X", mem, af, Rd);
		
	}

	else if (match (x, 0x6000000, 0xE000010)) /* load store register offset */
	{
		char s;
		char *af;
		char adr[30];
		char mem[30];
		char im[30];
//	fprintf (fdasm, "*1*");
		if (x & 0x800000)
			s = '+';
		else
			s = '-';
//	fprintf (fdasm, "*2*");
		sprintf (im, "R%X %s %X", Rm, shift[field(x,0x60)], field(x,0xF80));
//	fprintf (fdasm, "*3*");
		if (match (x, 0x6000000, 0xF200000))
		{
			af = "=";
			sprintf (adr, "R%X,%c=%s", Rn, s, im);
		}
		else if (match (x, 0x6200000, 0xF200000))
		{
			af = "=U";
			sprintf (adr, "R%X,%c=%s", Rn, s, im);
		}
		else if (match (x, 0x7000000, 0xF200000))
		{
			af = "=";
			sprintf (adr, "R%X%c%s", Rn, s, im);
		}
		else if (match (x, 0x7200000, 0xF200000))
		{
			af = "=";
			sprintf (adr, "R%X%c=%s", Rn, s, im);
		}
		else
		{
			af = "?";
			sprintf (adr, "?");
		}
//	fprintf (fdasm, "*4");
		if (x & 0x400000)
			sprintf (mem, "$[ %s]", adr);
		else
			sprintf (mem, "[%s]", adr);
/*	fprintf (fdasm, "*5*");
	fprintf (fdasm, "*i=%d*", i);
	fprintf (fdasm, "*Rd=%X*", Rd);
	fprintf (fdasm, "*af=%s*", af);
	fprintf (fdasm, "*mem=%s*", mem);
*/		if (!strcmp (af, "?"))
			i += sprintf (buf, "%X", x);
		else if (x & 0x100000)
			i += sprintf (buf+i, "R%X %s %s", Rd, af, mem);
		else
			i += sprintf (buf+i, "%s %s R%X", mem, af, Rd);
//	fprintf (fdasm, "*6");
	}

	else if (match (x, 0x8000000, 0xE000000)) /* load store multiple */
	{
		char mem[30];
		char *af;

		if (x & 0x400000)
			af = "?=";
		else
			af = "=";

		if (match (x, 0x8000000, 0xFA00000)) sprintf (mem, "[R%X-]", Rn); else 
		if (match (x, 0x8200000, 0xFA00000)) sprintf (mem, "[R%X-=]", Rn); else
		if (match (x, 0x8800000, 0xFA00000)) sprintf (mem, "[R%X+]", Rn); else
		if (match (x, 0x8A00000, 0xFA00000)) sprintf (mem, "[R%X+=]", Rn); else
		if (match (x, 0x9000000, 0xFA00000)) sprintf (mem, "[R%X--]", Rn); else
		if (match (x, 0x9200000, 0xFA00000)) sprintf (mem, "[R%X--=]", Rn); else
		if (match (x, 0x9800000, 0xFA00000)) sprintf (mem, "[R%X++]", Rn); else
		if (match (x, 0x9A00000, 0xFA00000)) sprintf (mem, "[R%X++=]", Rn); else
		sprintf (mem, "?");

		if (x & 0x100000)
			i += sprintf (buf+i, "RR#%04X %s %s", field(x,0xFFFF), af, mem);
		else
			i += sprintf (buf+i, "%s %s RR#%04X", mem, af, field(x,0xFFFF));
			
	}

	else if (match (x, 0x1000090, 0xFF00FF0)) /* swap */
		i += sprintf (buf+i, "R%X = [R%X] = R%X", Rd, Rn, Rm);
	else if (match (x, 0x1400090, 0xFF00FF0)) /* swap bytes */
		i += sprintf (buf+i, "R%X = $[R%X] = R%X", Rd, Rn, Rm);

	else if (match (x, 0x1900F9F, 0xFF00FFF)) /* LDREX */
		i += sprintf (buf+i, "R%X X= [R%X]", Rd, Rn);
	else if (match (x, 0x1800F9F, 0xFF00FFF)) /* STREX */
		i += sprintf (buf+i, "[R%X] X= R%X", Rn, Rd);

	else if (match (x, 0x19000D0, 0xFF00FF0)) /* load signed byte register offset */
		i += sprintf (buf+i, "R%X = +$[R%X+R%X]", Rd, Rn, Rm);

	else if (match (x, 0x04000D0, 0xE4000F0))
	{
		char mem[30];
		char s;
		unsigned int ofs;
		ofs = (x&0xF) | ((x&0xF00)>>4);
		if (x & 0x800000)
			s = '+';
		else
			s = '-';
		if (match (x, 0x04000D0, 0xE6000F0))
			sprintf (mem, "$$[R%X,%c=%X]", Rn, s, ofs);
		else if (match (x, 0x14000D0, 0xE6000F0))
			sprintf (mem, "$$[R%X%c=%X]", Rn, s, ofs);
		else if (match (x, 0x16000D0, 0xE6000F0))
			sprintf (mem, "$$[R%X%c%X]", Rn, s, ofs);
		else
			sprintf (mem, "[?]");
		if (x & 100000)
			i += sprintf (buf+i, "R%X = %s", Rd, mem);
		else
			i += sprintf (buf+i, "%s = R%X", mem, Rd);
	}

	else if (match (x, 0x0000090, 0xFF0F0F0))
		i += sprintf (buf+i, "R%X = R%X * R%X", field(x,0xF0000), field(x,0xF00), field(x,0xF));

	else
		i += sprintf (buf, "%X", x);
outbuf:
	buf[i] = 0;
	fprintf (out, "%s", buf);
}

void printascii (FILE *out, unsigned int x)
{
	int i;
	fprintf (out, "   \"");
	for (i=0; i<4; i++)
	{
		char c;
		c = x>>8*i;
		if (c >= 0x20 && c <= 0x7E)
			fprintf (out, "%c", c);
		else
			fprintf (out, ".");
	}
	fprintf (out, "\"");
}

void dumpcode (char *s, void *a, void *b)
{
	unsigned int *p;
	// labels[l] = a;

	if (dasm)
	{
		if (*s)
			fprintf (fdasm, "%s,", s);
	}
	// else
	//	fprintf (fdasm, "@%X %s\n", l, s);

	for (p=a; p<(unsigned int *)b; p++)
	{
		if (dasm)
			fprintf (fdasm, "%X: ", p);
		else
			fprintf (fdasm, "%08X %8X ", *p, p);
		printasm (fdasm, *p, (unsigned int)p);
		// fprintf (out, "   \"%c%c%c%c\"\n", *p, *p>>8, *p>>16, *p>>24);
		if (!dasm)
			printascii (fdasm, *p);
		if (dasm)
			fprintf (fdasm, " \t %% %X", *p);
		fprintf (fdasm, "\n");
	}
	fprintf (fdasm, "\n");
}

void dumpstring (char *s, void *a, void *b)
{
	char *p;
	// labels[l] = a;

	if (dasm)
		fprintf (fdasm, "%s,", s);
	// else
	//	fprintf (fdasm, "@%X %s\n", l, s);
	
	if (dasm)
		fprintf (fdasm, "%X: ", a);
	else
		fprintf (fdasm, "%08X %8X ", *p, p);

	fprintf (fdasm, "\"");

	for (p=a; p<(char *)b; p++)
		if (*p >= 0x20 && *p <= 0x7E)
			fprintf (fdasm, "%c", *p);

	fprintf (fdasm, "\"\n\n");
}

void dumpdata (char *s, void *a, void *b)
{
	unsigned int *p;
	fprintf (fdasm, "%s,%X: ", s, a);
	for (p=a; p<(unsigned int *)b; p++)
		fprintf (fdasm, "%08X\n", *p);
}

void dumpvar (char *s, int size)
{
	int sizea;
	sizea = ((size+3) / 4) * 4;
	fprintf (fdasm, "%s: RS %X\n", s, sizea);
}

void endfunction2 (void);

#define DF(f) tabf[nf].ptr=f; tabf[nf].name=#f; nf++; 
#define DA(xxx) tabadr[nadr].adr = (int)xxx; tabadr[nadr].name = #xxx; nadr++; 
 
int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPWSTR lpszCmdLine, int nCmdShow)
{
	int x;
	FILE *out;

	initf();

	
	
	// fprintf (out, "fopen=%X\n",fopen);
/*
	DF(fopen)
	DF(fclose)
	DF(fprintf)
	DF(calcul)
	DF(filename)
	DF(mode)
	DF(text)
*/
		DA(fopen)
		DA(fclose)
		DA(fprintf)
		DA(fscanf)
		DA(fgets)
		DA(feof)
		DA(sprintf)
		DA(sscanf)
		DA(strcmp)
		DA(strncmp)
		DA(strcpy)
		DA(strncpy)
		DA(strlen)

		DA(filename)
		DA(mode)
		DA(text)
	
		DA(prog)
		DA(calcul)

		DA(&gfdasm)
		DA(&out)
		DA(code)
		DA(&adr)
		DA(labels)
		DA(nl)
		DA(str)

		DA(initf)
		DA(isd)
		DA(instrcode)
		DA(asm)
		DA(substlabels)
		DA(callcode)
		DA(loadasm)
		DA(start)

		fdasm = fopen ("\\Carte de stockage\\test\\prog.txt", "w");

		dumpcode ("prog", prog, endprog);
		dumpcode ("calcul", calcul, prog);

		dumpstring ("filename", filename, mode);
		dumpstring ("mode", mode, text);
		dumpstring ("text", text, utext);
		dumpdata ("utext", utext, enddataprog);

		fclose(fdasm);


#ifdef DASMAS	
	fdasm = fopen ("\\Carte de stockage\\test\\dasmas.txt","w");
#else
	fdasm = fopen ("\\Carte de stockage\\test\\dasma.txt","w");
#endif
		dumpcode ("start", start, endstart);
		dumpcode ("match", match, initf);
		dumpcode ("initf", initf, isd);
		dumpcode ("isd", isd, instrcode);
		dumpcode ("instrcode", instrcode, asm);
		dumpcode ("asm", asm, substlabels);
		dumpcode ("substlabels", substlabels, callcode);
		dumpcode ("callcode", callcode, loadasm);
		dumpcode ("loadasm", loadasm, start);

		dumpvar ("&gfdasm", sizeof(gfdasm));
		dumpvar ("&out", sizeof(out));
		dumpvar ("&adr", sizeof(adr));
		dumpvar ("nl", sizeof(nl));
		dumpvar ("str", sizeof(str));
		dumpvar ("labels", sizeof(labels));
		dumpvar ("code", sizeof(code));


/*
	DA(calcul)
	DA(filename)
	DA(mode)
	DA(text)
	dumpcode (0, "start", start, start1);
	dumpcode (1, "calcul", calcul, start);
	dumpstring (2, "filename", filename, mode);
	dumpstring (3, "mode", mode, text);
	dumpstring (4, "text", text, enddata);
*/
	/*
	dumpcode (5, "", endfunction, endfunction2);
	dumpcode (6, "", endfunction2, &ghInstance);
	dumpcode (7, "start1", start1, endfunction);
	*/

	// start (functions, (int (*[]) () ) labels);
	// start (functions, ulabels.f);

	// prog (0);

	fprintf (fdasm, "%% starting...\n");
#ifdef DASMAS
	x = start (fdasm);
#else
	out = fopen ("\\Carte de stockage\\test\\loadasm.txt", "w");
	x = start (out);
#endif
	fprintf (fdasm, "%% Result = %X.\n", x);
}

/****************************************************************************
 *                                                                          *
 * Function: WinMain                                                        *
 *                                                                          *
 * Purpose : Initialize the application.  Register a window class,          *
 *           create and display the main window and enter the               *
 *           message loop.                                                  *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

int PASCAL WinMain1 (HINSTANCE hInstance, HINSTANCE hPrevInstance, LPWSTR lpszCmdLine, int nCmdShow)
{
    HWND hwnd;
    MSG msg;

    /* Always check first if program is already running */
    hwnd = FindWindow(L"dasmaClass", NULL);
    if (hwnd)
    {
        /*
         * Set focus to the foremost child window. The "|0x01" is used to
         * bring any owned windows to the foreground and activate them.
         */
        SetForegroundWindow((HWND)((ULONG)hwnd|0x00000001));
        return 0;
    }

    if (!hPrevInstance)
    {
        WNDCLASS wc;

        wc.lpszClassName = L"dasmaClass";
        wc.lpfnWndProc = MainWndProc;
        wc.style = CS_VREDRAW|CS_HREDRAW;
        wc.hInstance = hInstance;
        wc.hIcon = NULL;
        wc.hCursor = NULL;
        wc.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
        wc.lpszMenuName = NULL;
        wc.cbClsExtra = 0;
        wc.cbWndExtra = 0;

        if (!RegisterClass(&wc))
            return 1;
    }

    ghInstance = hInstance;

    hwnd = CreateWindowEx(
        0,
        L"dasmaClass",
        L"dasma Program",
        WS_VISIBLE|WS_SYSMENU,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        NULL,
        NULL,
        hInstance,
        NULL
    );
    if (!hwnd) return 1;

    /*
     * When CW_USEDEFAULT is used to create the main window, the height of the
     * menu bar is not considered. We must manually reserve space for the menu.
     */
    if (ghwndMB)
    {
        RECT rcWin, rcMB;

        GetWindowRect(hwnd, &rcWin);
        GetWindowRect(ghwndMB, &rcMB);
        rcWin.bottom -= (rcMB.bottom - rcMB.top);
        MoveWindow(hwnd, rcWin.left, rcWin.top, rcWin.right - rcWin.left, rcWin.bottom - rcWin.top, FALSE);
    }

    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    while (GetMessage(&msg, NULL, 0, 0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return msg.wParam;
}

/****************************************************************************
 *                                                                          *
 * Function: MainWndProc                                                    *
 *                                                                          *
 * Purpose : Process application messages.                                  *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static LRESULT CALLBACK MainWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
        HANDLE_MSG(hwnd, WM_CREATE, Main_OnCreate);
        HANDLE_MSG(hwnd, WM_ACTIVATE, Main_OnActivate);
        HANDLE_MSG(hwnd, WM_SETTINGCHANGE, Main_OnSettingChange);
        HANDLE_MSG(hwnd, WM_PAINT, Main_OnPaint);
        HANDLE_MSG(hwnd, WM_COMMAND, Main_OnCommand);
        HANDLE_MSG(hwnd, WM_DESTROY, Main_OnDestroy);
        /* TODO: enter more messages here */
        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }
}

/****************************************************************************
 *                                                                          *
 * Function: Main_OnCreate                                                  *
 *                                                                          *
 * Purpose : Process a WM_CREATE message.                                   *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static BOOL Main_OnCreate(HWND hwnd, CREATESTRUCT *pcs)
{
    SHMENUBARINFO mbi;

    memset(&mbi, 0, sizeof(mbi));
    mbi.cbSize = sizeof(mbi);
    mbi.hwndParent = hwnd;
    mbi.nToolBarId = IDR_MNU_MAIN;
    mbi.hInstRes = ghInstance;
    mbi.nBmpId = 0;
    mbi.cBmpImages = 0;
    if (!SHCreateMenuBar(&mbi))  /* create the menu bar */
        return FALSE;

    ghwndMB = mbi.hwndMB;

    return TRUE;
}

/****************************************************************************
 *                                                                          *
 * Function: Main_OnActivate                                                *
 *                                                                          *
 * Purpose : Process a WM_ACTIVATE message.                                 *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static void Main_OnActivate(HWND hwnd, UINT state, HWND hwndActDeact, BOOL fMinimized)
{
    /* Notify the shell of our activate message */
    SHHandleWMActivate(hwnd, MAKEWPARAM(state,fMinimized), (LPARAM)hwndActDeact, &gsai, 0);
}

/****************************************************************************
 *                                                                          *
 * Function: Main_OnSettingChange                                           *
 *                                                                          *
 * Purpose : Process a WM_SETTINGCHANGE message.                            *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static void Main_OnSettingChange(HWND hwnd, UINT uiAction, PCTSTR pszSection)
{
    switch (uiAction)
    {
        case SPI_SETSIPINFO:
        {
            /* Adjust window size depending on SIP panel */
            SHHandleWMSettingChange(hwnd, -1, 0, &gsai);
            break;
        }
    }
}

/****************************************************************************
 *                                                                          *
 * Function: Main_OnPaint                                                   *
 *                                                                          *
 * Purpose : Process a WM_PAINT message.                                    *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static void Main_OnPaint(HWND hwnd)
{
    PAINTSTRUCT ps;
    RECT rc;

    BeginPaint(hwnd, &ps);
    GetClientRect(hwnd, &rc);
    DrawText(ps.hdc, L"Hello, Windows CE!", -1, &rc, DT_CENTER|DT_VCENTER);
    EndPaint(hwnd, &ps);
}

/****************************************************************************
 *                                                                          *
 * Function: Main_OnCommand                                                 *
 *                                                                          *
 * Purpose : Process a WM_COMMAND message.                                  *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static void Main_OnCommand(HWND hwnd, int id, HWND hwndCtl, UINT codeNotify)
{
    switch (id)
    {
        case IDM_ABOUT:
            DialogBox(ghInstance, MAKEINTRESOURCE(DLG_ABOUT), hwnd, (DLGPROC)AboutDlgProc);
            break;

        case IDOK:
            SendMessage(hwnd, WM_CLOSE, 0, 0);
            break;

        default:
            FORWARD_WM_COMMAND(hwnd, id, hwndCtl, codeNotify, DefWindowProc);
            break;

        /* TODO: Enter more commands here */
    }
}

/****************************************************************************
 *                                                                          *
 * Function: Main_OnDestroy                                                 *
 *                                                                          *
 * Purpose : Process a WM_DESTROY message.                                  *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static void Main_OnDestroy(HWND hwnd)
{
    DestroyWindow(ghwndMB);
    PostQuitMessage(0);
}

/****************************************************************************
 *                                                                          *
 * Function: AboutDlgProc                                                   *
 *                                                                          *
 * Purpose : Process messages for the About dialog.  The dialog is          *
             shown when the user selects "About" in the "Help" menu.        *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static LRESULT CALLBACK AboutDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)
    {
        case WM_INITDIALOG:
        {
            SHINITDLGINFO shidi;

            /*
             * Create a Done button and size the dialog.
             */
            shidi.dwMask = SHIDIM_FLAGS;
            shidi.dwFlags = SHIDIF_DONEBUTTON|SHIDIF_SIPDOWN|SHIDIF_SIZEDLGFULLSCREEN;
            shidi.hDlg = hDlg;
            SHInitDialog(&shidi);
            return TRUE;
        }

        case WM_COMMAND:
            switch (wParam)
            {
                case IDOK:
                    /*
                     * OK was clicked, close the dialog.
                     */
                    EndDialog(hDlg, TRUE);
                    return TRUE;
            }
            break;
    }

    return FALSE;
}
