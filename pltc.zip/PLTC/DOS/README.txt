PLTC : Prolog to Turbo C compiler

This project is made of a compiler PLTOC.C and a runtime system SCHEDULE.C, EXPR.C and PROLOG.C.
All these C sources can be compiled with Turbo C.

To run a Prolog program (for example APPEND.PRO) :
- compile it into C :
    PLTOC APPEND.PRO APPEND.C
- build APPEND.EXE by linking together APPEND.OBJ, SCHEDULE.OBJ, EXPR.OBJ and PROLOG.OBJ. This can be done with Turbo C by selecting the project APPEND.PRJ (menu Project / Project name).
- Run APPEND.EXE

