
#include <stdio.h>

main ()
{
    int c;
    for (;;)
    {
        c = getchar();
        if (c==EOF) break;
        if (c!=13) putchar(c);
    }
}

        



